Metin2 Singleplayer world backup

Made:          2026-10-07 09:57:46
Volume:        m2pb-766485d3_db-data
Characters:    5465
Highest level: 90

Contents (mariadb-dump dumps, latin1 as in the game):
  account.sql     1.986.662 B
  common.sql      1.027.718 B
  world.sql       4.386.844 B
  player.sql     11.459.307 B
  log.sql        50.606.816 B
  hotbackup.sql        1.351 B

To restore it: launcher -> BACKUP / NEW WORLD -> Restore from a backup, and point to this folder or the zip.
